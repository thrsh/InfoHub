<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "infohub_db";
?>