<?php
$actual_link = $_SERVER['HTTP_HOST'];

$default_timezone = 'Asia/Manila';
$smtp_host = 'smtp.gmail.com';
$smtp_user = 'itseley09@gmail.com';
$smtp_pass = 'qqnjgysrulaanxmu';

$contact_mail = 'itseley09@gmail.com';

$fb  = 'https://www.facebook.com/profile.php?id=100088165601836';
$tw = 'https://www.facebook.com/profile.php?id=100088165601836';
$ig = 'https://www.facebook.com/profile.php?id=100088165601836';
?>