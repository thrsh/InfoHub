<?php
session_start();
if (isset($_SESSION['logged']) && $_SESSION['logged'] == true) {
    $myid = $_SESSION['myid'];
    $myfname = $_SESSION['myfname'];
    $mylname = $_SESSION['mylname'];
    $myemail = $_SESSION['myemail'];
    $mylogin = $_SESSION['lastlogin'];
    $myrole = $_SESSION['role'];
$user_online = true;	
}else{
$user_online = false;
}
?>