<?php
date_default_timezone_set('Asia/Manila');
$checkpass = $_POST['password1'];
if (isset($_POST['password1'])) {
checkemail();	
}else{
header("location:../");		
}


function checkemail() {
	
try {
	require '../../constants/db_config.php';

    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$checkpass = $_POST['password1'];
	$myid = $_POST['myid'];
	
    $stmt = $conn->prepare("SELECT * FROM tbl_users WHERE user_no = :myid");
	$stmt->bindParam(':myid', $myid);
    $stmt->execute();
    $result = $stmt->fetchAll();
    
    foreach($result as $row) {
        $user_no = $row['user_no'];
       $passw = $row['passw'];
    }

	
	
	if ($passw == $checkpass) {
        
	header("location:../add-users.php?p=$role&r=0927");	
		
	}else{
	
	if ($account_type == "instructor") {
	register_as_instructor();
	}else{
	register_as_staff();
	}
	
		
	}
					  
	}catch(PDOException $e)
    {
    header("location:../add-users.php?p=$role&r=4568");
    }
}

function register_as_instructor() {

try {
	require '../../constants/db_config.php';
	require '../../constants/uniques.php';
	$role = 'instructor';
    $account_type = $_POST['accType'];
    $last_login = date('d-m-Y h:m A [T P]');
	$user_no = 'INS'.get_rand_numbers(9).'';
    $first_name = ucwords($_POST['fname']);
    $last_name = ucwords($_POST['lname']);
    $email = $_POST['email'];
    $passw = md5($_POST['password']);
	
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("INSERT INTO tbl_users (first_name, last_name, email, passw,user_no, last_login, role) 
	VALUES (:fname, :lname, :email, :passw, :userno, :lastlogin, :role)");
    $stmt->bindParam(':fname', $first_name);
    $stmt->bindParam(':lname', $last_name);
    $stmt->bindParam(':email', $email);
	$stmt->bindParam(':lastlogin', $last_login);
    $stmt->bindParam(':passw', $passw);
    $stmt->bindParam(':role', $role);
	$stmt->bindParam(':userno', $user_no);
    $stmt->execute();
	header("location:../add-users.php?p=Instructor&r=1123");				  
	}catch(PDOException $e)
    {
    header("location:../add-users.php?p=Instructor&r=4568");
    }	
	
}

function register_as_staff() {
try {
	require '../../constants/db_config.php';
	require '../../constants/uniques.php';
	$role = 'staff';
    $account_type = $_POST['accType'];
    $last_login = date('d-m-Y h:m A [T P]');
	$user_no = 'INS'.get_rand_numbers(9).'';
    $first_name = ucwords($_POST['fname']);
    $last_name = ucwords($_POST['lname']);
    $email = $_POST['email'];
    $passw = md5($_POST['password']);
	
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("INSERT INTO tbl_users (first_name, last_name, email, passw,user_no, last_login, role) 
	VALUES (:fname, :lname, :email, :passw, :userno, :lastlogin, :role)");
    $stmt->bindParam(':fname', $first_name);
    $stmt->bindParam(':lname', $last_name);
    $stmt->bindParam(':email', $email);
	$stmt->bindParam(':lastlogin', $last_login);
    $stmt->bindParam(':passw', $passw);
    $stmt->bindParam(':role', $role);
	$stmt->bindParam(':userno', $user_no);
    $stmt->execute();
	header("location:../add-users.php?p=Staff&r=1123");				  
	}catch(PDOException $e)
    {
    header("location:../add-users.php?p=Staff&r=4568");
    }	
	
}

?>