<!doctype html>
<html lang="en">
<?php 
include '../constants/settings.php'; 
include 'constants/check-login.php';
include '../constants/db_config.php';
require '../constants/db_config.php';
if ($user_online == "true") {
if ($myrole == "admin") {
}else{
header("location:../");		
}
}else{
header("location:../");	
}
?>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Infohub - View Staff</title>
	<meta name="description" content="Online Document Management system" />
	<meta name="keywords" content="document, file, management, , upload, files, documents, document management, online file management,  online documents management, file management system, document management system" />
	<meta name="author" content="BatState">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta property="og:image" content="http://<?php echo "$actual_link"; ?>/images/banner.jpg" />
    <meta property="og:image:secure_url" content="https://<?php echo "$actual_link"; ?>/images/banner.jpg" />
    <meta property="og:image:type" content="image/jpeg" />
    <meta property="og:image:width" content="500" />
    <meta property="og:image:height" content="300" />
    <meta property="og:image:alt" content="Infohub" />
    <meta property="og:description" content="Online Document Management system" />

    <link rel="shortcut icon" href="../images/ico/icon-72.png">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdn.datatables.net/1.13.5/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css" media="screen">
    <link href="../css/animate.css" rel="stylesheet">
    <link href="../css/main.css" rel="stylesheet">
    <link href="../css/component.css" rel="stylesheet">

    <link rel="stylesheet" href="../icons/linearicons/style.css">
    <link rel="stylesheet" href="../icons/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../icons/simple-line-icons/css/simple-line-icons.css">
    <link rel="stylesheet" href="../icons/ionicons/css/ionicons.css">
    <link rel="stylesheet" href="../icons/pe-icon-7-stroke/css/pe-icon-7-stroke.css">
    <link rel="stylesheet" href="../icons/rivolicons/style.css">
    <link rel="stylesheet" href="../icons/flaticon-line-icon-set/flaticon-line-icon-set.css">
    <link rel="stylesheet" href="../icons/flaticon-streamline-outline/flaticon-streamline-outline.css">
    <link rel="stylesheet" href="../icons/flaticon-thick-icons/flaticon-thick.css">
    <link rel="stylesheet" href="../icons/flaticon-ventures/flaticon-ventures.css">

    <link href="../css/style.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.5/css/jquery.dataTables.css" />
	

    <script src="../js/jquery-1.11.3.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script type="text/javascript" src="../js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="../js/dataTables.bootstrap.min.js"></script>

    
</head>
  <style>
  
    .autofit2 {
	height:80px;
	width:100px;
    object-fit:cover; 
  }
  
  </style>

<body class="not-transparent-header">

	<div class="container-wrapper">

		<header id="header">


			<nav class="navbar navbar-default navbar-fixed-top navbar-sticky-function">

				<div class="container">
					
					<div class="logo-wrapper">
						<!-- <div class="logo">
							<a href="../"><img src="../images/nasugbujobs-logo1.png" alt="Logo" /></a>
						</div> -->
					</div>
					
					<div id="navbar" class="navbar-nav-wrapper navbar-arrow">
					
						<ul class="nav navbar-nav" id="responsive-menu">
						
							<li>
							
								<a href="../"></a>
								
							</li>
							
							<li>
								<a href="../"></a>

							</li>
							
							<li>
								<a href="../"></a>
							</li>
					
						</ul>
				
					</div>

					<div class="nav-mini-wrapper">
						<ul class="nav-mini sign-in">
							<li><a href="../logout.php">logout</a></li>
							<li><a href="./">Profile</a></li>
						</ul>
					</div>
				
				</div>
				
				<div id="slicknav-mobile"></div>
				
			</nav>

			
		</header>

		<div class="main-wrapper">
		
			<div class="breadcrumb-wrapper">
			
				<div class="container">
				
					<ol class="breadcrumb-list booking-step">
						<li><a href="../">Admin</a></li>
						<li><span>View Staff</span></li>
					</ol>
					
				</div>
				
			</div>
		
	</div>
			<div class="admin-container-wrapper">

				<div class="container">
				
					<div class="GridLex-gap-15-wrappper">
					
						<div class="GridLex-grid-noGutter-equalHeight">
						
							<div class="GridLex-col-3_sm-4_xs-12">
							
								<div class="admin-sidebar">
										
									<div class="admin-user-item">
									<!-- <div class="image">	
									
										<?php 
										if ($myavatar == null) {
										print '<center><img class="img-circle autofit2" src="../images/default.jpg" title="'.$myfname.'" alt="image"  /></center>';
										}else{
										echo '<center><img class="img-circle autofit2" alt="image" title="'.$myfname.'"  src="data:image/jpeg;base64,'.base64_encode($myavatar).'"/></center>';	
										}
										?>
										</div> -->
										<br>
										
										
										<h4><?php echo "$myfname"; ?> <?php echo "$mylname"; ?></h4>
										<p class="user-role"><?php echo "$myrole"; ?></p>
										
									</div>
									
									<div class="admin-user-action text-center">
										
									</div>
									
									<ul class="admin-user-menu clearfix">
									<li  class="">
											<a href="./"><i class="fa fa-user"></i> Profile</a>
										</li>
										<!-- <li>
											<a href="change-password.php"><i class="fa fa-key"></i> Change Password</a>
										</li> -->
										<li>
											<a href="view-dashboard.php"><i class="fa fa-bar-chart"></i>View Dashboard</a>
										</li>
										<li class="active">
											<a href="view-staff.php"><i class="fa fa fa-building"></i>View Staff</a>
										</li>
										<li class="">
											<a href="view-instructors.php"><i class="fa fa-users"></i>View Instructors</a>
										</li>
										<!-- <li class="">
											<a href="add-documents.php"><i class="fa fa-file"></i>Add Documents</a>
										</li> -->
										
										<li class="">
											<a href="view-documents.php">
												<i class="fa fa-envelope"></i> View Documents
											</a>
										</li>
										<li class="">
											<a href="add-users.php">
												<i class="fa fa-user-plus"></i> Add Users
											</a>
										</li>
										<li class="">
											<a href="view-requests.php">
												<i class="fa fa-user-plus"></i> View Requests
											</a>
										</li>
										<li>
											<a href="../logout.php"><i class="fa fa-sign-out"></i> Logout</a>
										</li>
									</ul>
									
								</div>

							</div>
							
							<div class="GridLex-col-9_sm-8_xs-12">
							
								<div class="admin-content-wrapper">

									<div class="admin-section-title">
									
										<h2>View Staff</h2>
	
										
									</div>
									<?php require 'constants/check_reply.php'; ?>
									
									
									<div class="container-fluid">
                                        <div class="row ">
                                        <div class="col-md-12 ">
                                                <div class="col-md-12 mx-auto mt-3">
                                                    
												<div class="">
   											 <!--   <button type="button" class="btn btn-success" data-toggle="modal" data-target="#modalRegisterForm">Add File</button> -->
											<!-- <a href="add_file.php"><button type="button" class="btn btn-danger"><i class="fas fa-file-medical"></i>  Add File</button></a> -->
											</div>
  
										
										<div class="col-md-12">
                                                    <table id="dtable" class="table table-striped">
													
                                                        <thead>
                                                            <tr>
                                                                <th style='text-align: center;'>Name</th>
                                                                <th style='text-align: center;'>Email</th>
                                                                <th style='text-align: center;'>User No</th>
                                                                <th style='text-align: center;'>Action</th>
                                                            </tr>
                                                        </thead>
														<tbody>
                                                            <?php
                                                            require '../constants/db_config.php';
                                                            $conn = mysqli_connect($servername, $username, $password, $dbname);
                                                            $query = mysqli_query($conn, "SELECT DISTINCT first_name, last_name, email, user_no FROM tbl_users WHERE role = 'staff' GROUP BY first_name DESC ") or die(mysqli_error($conn));
                                                            while ($users = mysqli_fetch_array($query)) {
                                                                $first_name = $users['first_name'];
                                                                $last_name = $users['last_name'];
                                                                $email = $users['email'];
                                                                $user_no = $users['user_no'];
                                                                $fullname = $first_name . " " . $last_name;
                                                            ?>
                                                                <tr>
                                                                    <td width="20%"><?php echo $fullname; ?></td>
                                                                    <td style='text-align: center;'><?php echo $email; ?></td>
                                                                    <td style='text-align: center;'><?php echo $user_no; ?></td>
                                                                    <td>
                                                                        
                                                                        <a href='delete-staff.php?user_no=<?php echo $user_no; ?>' class="btn btn-sm btn-outline-danger">
                                                                            <i class="fa fa-trash"></i>
                                                                        </a>
                                                                        <a href="#modalRegisterFormss?user_no=<?php echo $user_no;?>"><i class="fas fa-user-edit" data-toggle="modal" data-target="#modalRegisterFormss"></i></a>
                                                                    </td>
                                                                </tr>
                                                            <?php } ?>
                                                        </tbody>
                                                    </table>
    											</div>
                                                </div>
                                            </div>
                                        </div>
                                            
                                        </div>
<!-- end -->
							</div>
							
						</div>

					</div>

				</div>
			
			</div>
			<footer class="footer-wrapper">
			
				<div class="main-footer">
				
					<div class="container">
					
						<div class="row">
						
							<div class="col-sm-12 col-md-9">
							
								<div class="row">
								
									<div class="col-sm-6 col-md-4">
									
										<div class="footer-about-us">
										<h5 class="footer-title">About Infohub</h5>
										<p>Infohub is an Online Document Management System developed the Records Management Office ARASOF-Nasugbu.</p>
										</div>

									</div>
									
									

								</div>

							</div>
							
							<div class="col-sm-12 col-md-3 mt-30-sm ">
							
								<h5 class="footer-title">Infohub Contact</h5>
								
								<p>Address : BRGY. BUCANA, APACIBLE BLVD. NASUGBU, BATANGAS</p>
								<p>Email : <a href="mailto:Infohub@gmail.com">infohub@gmail.com</a></p>
								<p>Phone : <a href="tel:+639999999999">+6399 9999 9999</a></p>

							</div>

							
						</div>
						
					</div>
					
				</div>
				
				<div class="bottom-footer">
				
					<div class="container">
					
						<div class="row">
						
							<div class="col-sm-4 col-md-4">
							<p class="copy-right">&#169; Copyright <?php echo date('Y'); ?> Infohub</p>
							</div>
							
							<div class="col-sm-4 col-md-4">
							
								<ul class="bottom-footer-menu">
								<!-- <li><a >Developed by Team Amigos</a></li> -->
								</ul>
							
							</div>
							

						
						</div>

					</div>
					
				</div>
			
			</footer>
			
		</div>
	

	</div> 

<div id="back-to-top">
   <a href="#"><i class="ion-ios-arrow-up"></i></a>
</div>

<script type="text/javascript" src="../js/jquery-1.11.3.min.js"></script>
<script type="text/javascript" src="../js/jquery-migrate-1.2.1.min.js"></script>
<script type="text/javascript" src="../bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="../js/bootstrap-modalmanager.js"></script>
<script type="text/javascript" src="../js/bootstrap-modal.js"></script>
<script type="text/javascript" src="../js/smoothscroll.js"></script>
<script type="text/javascript" src="../js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="../js/jquery.waypoints.min.js"></script>
<script type="text/javascript" src="../js/wow.min.js"></script>
<script type="text/javascript" src="../js/jquery.slicknav.min.js"></script>
<script type="text/javascript" src="../js/jquery.placeholder.min.js"></script>
<script type="text/javascript" src="../js/bootstrap-tokenfield.js"></script>
<script type="text/javascript" src="../js/typeahead.bundle.min.js"></script>
<script type="text/javascript" src="../js/bootstrap3-wysihtml5.min.js"></script>
<script type="text/javascript" src="../js/bootstrap-select.min.js"></script>
<script type="text/javascript" src="../js/jquery-filestyle.min.js"></script>
<script type="text/javascript" src="../js/bootstrap-select.js"></script>
<script type="text/javascript" src="../js/ion.rangeSlider.min.js"></script>
<script type="text/javascript" src="../js/handlebars.min.js"></script>
<script type="text/javascript" src="../js/jquery.countimator.js"></script>
<script type="text/javascript" src="../js/jquery.countimator.wheel.js"></script>
<script type="text/javascript" src="../js/slick.min.js"></script>
<script type="text/javascript" src="../js/easy-ticker.js"></script>
<script type="text/javascript" src="../js/jquery.introLoader.min.js"></script>
<script type="text/javascript" src="../js/jquery.responsivegrid.js"></script>
<script type="text/javascript" src="../js/customs.js"></script>
<script type="text/javascript" src="../js/fileinput.min.js"></script>
<script type="text/javascript" src="../js/customs-fileinput.js"></script>
<script src="../js/jquery-1.11.3.min.js"></script>

<script src="https://code.jquery.com/jquery-3.7.0.js"></script>
<script src="https://cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.5/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>

	<!-- <script>
		$(document).ready(function() {
			
			$('#dtable').DataTable({
				"lengthMenu": [[5, 10, 15, 25, 50, 100, -1], [5, 10, 15, 25, 50, 100, "All"]],
                "pageLength": 10,
				responsive: true,
				language:{
					
					searchPlaceholder:"Search Users",
				}
			
				
			});

			$('#search').on('keyup', function() {
				$('#dtable').DataTable().search($(this).val()).draw();
			});
			
		});
		
	</script> -->
	
	<script>
		new DataTable('#dtable', {
    initComplete: function () {
        this.api()
            .columns()
            .every(function () {
                let column = this;
                let title = column.footer().textContent;
 
                // Create input element
                let input = document.createElement('input');
                input.placeholder = title;
                column.footer().replaceChildren(input);
 
                // Event listener for user input
                input.addEventListener('keyup', () => {
                    if (column.search() !== this.value) {
                        column.search(input.value).draw();
                    }
                });
            });
    }
});
	</script>

<div class="modal fade" id="modalRegisterFormss" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
  aria-hidden="true">
    <?php 

include '../constants/db_config.php';
  $conn = mysqli_connect($servername, $username, $password, $dbname);
$q = mysqli_query($conn,"select * from tbl_users where user_no = '$user_no'") or die (mysqli_error($conn));
 $rs1 = mysqli_fetch_array($q);
 
               $user_no=$rs1['user_no'];
               $fname=$rs1['first_name'];
               $lname=$rs1['last_name'];
               $email=$rs1['email'];
               $passw=$rs1['passw'];
?>
  <div class="modal-dialog" role="document">
    <form method="POST">
    
    <div class="modal-content">
      <div class="modal-header text-center">
        <h4 class="modal-title w-100 font-weight-bold"><i class="fas fa-user-edit"></i> Edit User</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
        <div class="modal-body mx-3">
           <div class="md-form mb-5">
            <input type="hidden" class="form-control" name="id" value="<?php echo $user_no;?>"><br>
        </div>
        <div class="md-form mb-5">
          <i class="fas fa-user prefix grey-text"></i>
          <input type="text" id="orangeForm-name" name="fname" value="<?php echo $fname;?>" class="form-control validate">
          <label data-error="Not Available" data-success="Available" for="orangeForm-name">First Name</label>
        </div>
        <div class="md-form mb-5">
          <i class="fas fa-user prefix grey-text"></i>
          <input type="text" id="orangeForm-name" name="lname" value="<?php echo $lname;?>" class="form-control validate">
          <label data-error="Not Available" data-success="Available" for="orangeForm-name">Last Name</label>
        </div>
        <div class="md-form mb-5">
          <i class="fas fa-envelope prefix grey-text"></i>
          <input type="email" id="orangeForm-email" name="email" value="<?php echo $email;?>" class="form-control validate">
          <label data-error="Not Available" data-success="Available" for="orangeForm-email">Email</label>
        </div>

        <div class="md-form mb-4">
          <i class="fas fa-lock prefix grey-text"></i>
          <input type="password" id="orangeForm-pass" name="passw" value="<?php echo $passw;?>" class="form-control validate">
          <label data-error="Not Available" data-success="Available" for="orangeForm-pass">Password</label>
        </div>
       
      </div>
      <div class="modal-footer d-flex justify-content-center">
        <button class="btn btn-primary" name="edit">UPDATE</button>
      </div>
    </div>
  </div>
</div>
</form>


 <?php 

include '../constants/db_config.php';
  $conn = mysqli_connect($servername, $username, $password, $dbname);
 if(isset($_POST['edit'])){
         $first_name = mysqli_real_escape_string($conn,$_POST['fname']);
         $last_name = mysqli_real_escape_string($conn,$_POST['lname']);
         $email = mysqli_real_escape_string($conn,$_POST['email']);
		 $passw = md5($_POST['passw']);
       
       //  $user_status = mysqli_real_escape_string($conn,$_POST['status']);

     mysqli_query($conn,"UPDATE `tbl_users` SET `first_name` = '$first_name', `last_name` = '$last_name',`email` = '$email', `passw` = '$passw' where id='$id'") or die (mysqli_error($conn));
  
  echo "<script type = 'text/javascript'>alert('Success Edit User/Employee!!!');document.location='view_user.php'</script>";

}

?>

</body>

</html>
