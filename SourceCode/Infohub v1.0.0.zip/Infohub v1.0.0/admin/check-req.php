<?php
require '../constants/db_config.php';
if (isset($_GET['rc'])) {
$reqcode = $_GET['rc'];

    try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

	
    $stmt = $conn->prepare("SELECT * FROM tbl_request_status WHERE id = :reqcode");
	$stmt->bindParam(':reqcode', $reqcode);
    $stmt->execute();
    $result = $stmt->fetchAll();

    foreach($result as $row)
    {
		
     $description = $row['status'];
     $type = $row['type'];
     print '
	 <div class="btn btn-sm btn-'.$type.'">
     '.$status.'
	 </div>
     ';
	}

					  
	}catch(PDOException $e)
    {

    }
	

}

?>