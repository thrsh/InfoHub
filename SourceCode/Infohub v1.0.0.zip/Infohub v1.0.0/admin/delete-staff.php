<?php
require '../constants/db_config.php';
require 'constants/check-login.php';
$memberno = $_GET['user_no'];

try {
$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


$stmt = $conn->prepare("DELETE FROM tbl_users WHERE user_no = :user_no ");
$stmt->bindParam(':user_no', $memberno);
$stmt->execute();

// $stmt = $conn->prepare("DELETE FROM tbl_requests WHERE user_no = :user_no ");
// $stmt->bindParam(':user_no', $user_no);
// $stmt->execute();
header("location:../admin/view-staff.php?r=9691");
}catch(PDOException $e)
{
  
}
	
?>