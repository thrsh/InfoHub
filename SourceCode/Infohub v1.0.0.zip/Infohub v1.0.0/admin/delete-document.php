<?php
require '../constants/db_config.php';
require 'constants/check-login.php';
$docID = $_GET['id'];

try {
$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


$stmt = $conn->prepare("DELETE FROM tbl_other_attachments WHERE id = :docID ");
$stmt->bindParam(':docID', $docID);
$stmt->execute();

// $stmt = $conn->prepare("DELETE FROM tbl_requests WHERE user_no = :user_no ");
// $stmt->bindParam(':user_no', $user_no);
// $stmt->execute();
header("location:../admin/view-documents.php?r=6784");
}catch(PDOException $e)
{
  
}
	
?>